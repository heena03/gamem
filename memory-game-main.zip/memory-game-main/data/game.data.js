const gameData = {
    isStarted: false,
    totalTime: 30,
    timeLeft: 30,
    boardSize: 10,
    moves: 0,
    closeCardsTimeout: 400,
    boardType: 'robot',
    board: []
}